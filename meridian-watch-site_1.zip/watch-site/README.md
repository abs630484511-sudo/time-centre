# Meridian Watch Co. – full-stack website
Node.js + Express. No build step. Data is stored in `data/db.json`.

## Run
```
npm install
npm start        # http://localhost:3000   admin: /admin
```
Default logins (change them first in Admin > Users):
- admin / admin123 – full control (site, content, SEO, watches, messages, users)
- author / author123 – edits page content, all SEO fields, and watch SEO

## Go live
1. Upload to a Node host (Render, Railway, VPS). Start command: `npm start`. Keep `data/` and `public/uploads/` on a persistent disk.
2. In Admin > Site settings set your real Site URL, add the Google Analytics ID and Search Console tag.
3. Submit `https://yourdomain.com/sitemap.xml` in Google Search Console. Serve over HTTPS.

## SEO included
Server-rendered pages, editable title/description/keywords/share image per page and per watch, canonical URLs, Open Graph and Twitter cards, JSON-LD (Organization, WebSite, Product, Breadcrumb), dynamic sitemap.xml, editable robots.txt, noindex admin, lazy images, semantic HTML.

## Images
Admin > Watches: upload a photo per watch. Admin > Site settings: upload a real watch photo as the home page hero background (or leave it empty for the default dial pattern).
